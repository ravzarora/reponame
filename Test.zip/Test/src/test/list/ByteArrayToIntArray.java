package test.list;

public class ByteArrayToIntArray {
	
	
    public int[] bytearray2intarray(byte[] barray)
 {
   int[] iarray = new int[barray.length];
   System.out.println("length of bytes is : "+barray.length);
   int i = 0;
   for (byte b : barray)
       iarray[i++] = b & 0xff;
   return iarray;
 }

}
