package test.list;

import java.math.BigInteger;
import java.nio.ByteBuffer;

public class ConstantBytes {

	public static WriteByteFile writeObj = new WriteByteFile();
	public static WriteBinaryFile binaryObj = new WriteBinaryFile();
	ByteArrayToIntArray conObj = new ByteArrayToIntArray();

	String outText = "";
	String s = "";

	public void writeConstantBytes(String array[], int count) {
		byte[] bytes = new byte[count];
		int i = 0;

		System.out.println("displaying only constant bytes");
		for (i = 3; i < count + 3; i++) {
			outText += array[i] + " ";
			byte temp = Byte.decode(array[i]);

			System.out.println("Byte value observed " + temp);
			bytes = ByteBuffer.allocate(count).put(i - 3, temp).array();
			System.out.println("In loop " + bytes[i - 3]);
			

			 s += Integer.toBinaryString(bytes[i - 3]);
	        
		}

		// System.out.println("out loop " +bytes[count-2]);

		

		s += " ";
		System.out.println(s);

		System.out.print(outText);
		// System.out.print(s);

		outText += "\n";
		writeObj.writeBytes(outText);

	}


}
