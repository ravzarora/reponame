package test.list;

import java.math.BigInteger;
import java.nio.ByteBuffer;

public class ConstantBytes {

	public static WriteByteFile writeObj = new WriteByteFile();
	public static WriteBinaryFile binaryObj = new WriteBinaryFile();

	String outText = "";
	String s = "";

	public void writeConstantBytes(String array[], int count) {
		byte[] bytes = new byte[count];
		int i = 0;
		
		String s="";
		System.out.println("displaying only constant bytes");
		for (i = 3; i < count + 3; i++) {
			outText += array[i] + " ";
			byte temp = Byte.decode(array[i]);
			bytes[i-3]=temp;
			System.out.println("Byte value observed " + temp);
			
		}
		//bytes = ByteBuffer.allocate(count).put(i-3, temp).array();
		BigInteger bi = new BigInteger(bytes);
		System.out.println("i am big integer : "+bi);
		
		
		 s = bi.toString(2);

		s += " ";
		System.out.println(s);

		System.out.print(outText);
		// System.out.print(s);

		outText += "\n";
		writeObj.writeBytes(outText);

	}

}
