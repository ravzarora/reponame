package at.fhhagenberg.mc.file.append;

import java.io.*;

import at.fhhagenberg.mc.file.ConstantBytes;

public class AppendFile {

	public void append(int count,String filepath){
		File file=new File(filepath);
		System.out.println("Apend mode");
		try {
			FileInputStream fin=new FileInputStream(file);
			byte fileContent[]=new byte[count];
			fin.read(fileContent);
			byte byteFileContent[]=new byte[count];
			for(int i=0;i<count;i++) {
				byteFileContent[i]=fileContent[i];
				
			}
			//for(int i=0;i<count;i++) {
			//	System.out.println(Integer.toHexString(byteFileContent[i]));
				ConstantBytes.binaryObj.writeBinary(byteFileContent);
			//}
		}catch(FileNotFoundException e) {
			System.out.println("File not found " + e);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception while reading the file " + e);
		}

		
	}

}
