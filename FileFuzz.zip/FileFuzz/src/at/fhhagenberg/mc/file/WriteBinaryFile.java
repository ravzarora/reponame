package at.fhhagenberg.mc.file;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;

public class WriteBinaryFile {

	public void writeBinary(byte[] bytes) {
		String outputPath = "res/binary.bin";
		try {
			FileOutputStream binWrite = new FileOutputStream(outputPath, true);
			ObjectOutputStream writer = new ObjectOutputStream(binWrite);
			writer.write(bytes);
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
