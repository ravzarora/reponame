package at.fhhagenberg.mc.file;

import java.math.BigInteger;
import java.nio.ByteBuffer;

public class ConstantBytes {

	public static WriteByteFile writeObj = new WriteByteFile();
	public static WriteBinaryFile binaryObj = new WriteBinaryFile();

	String outText = "";
	String s = "";

	public void writeConstantBytes(String array[], int count) {

		byte[] bytes = new byte[count];
		int i = 0;
		int j = 0;
		String s = "";
		System.out.println("displaying only constant bytes");
		System.out.println("iinitial length" + count);
		String[] tempArr = new String[array.length - 3];
		System.out.println("call+length " + tempArr.length);
		for (i = 3; i < count + 3; i++) {

			try {
				outText += array[i] + " ";
				byte temp = Byte.decode(array[i]);
				bytes[i - 3] = temp;

				tempArr[i - 3] = array[i];
				System.out.println("Byte value observed " + temp);
			} catch (ArrayIndexOutOfBoundsException exception) {

				// required=count-tempArr.length;
				System.out.println("call");
				outText += tempArr[j] + " ";
				byte temp = Byte.decode(tempArr[j]);
				bytes[i - 3] = temp;
				if (j < tempArr.length - 1)
					j++;
				else
					j = 0;
			}

		}
		// bytes = ByteBuffer.allocate(count).put(i-3, temp).array();
		BigInteger bi = new BigInteger(bytes);
		System.out.println("big integer : " + bi);

		s = bi.toString(2);

		s += " ";
		binaryObj.writeBinary(bytes);

		System.out.println(s);

		// for Kb
		byte[] bytes1 = ByteBuffer.allocate(1024).putInt(1).array();
		BigInteger bi2 = new BigInteger(bytes1);
		System.out.println("big integer for kb data : " + bi2);
		// binaryObj.writeBinary(bytes1);
		String s2 = bi2.toString(2);

		s2 += " ";

		System.out.println(s2);

		System.out.print(outText);
		// System.out.print(s);

		outText += "\n";
		writeObj.writeBytes(outText);

	}

}
