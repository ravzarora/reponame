package at.fhhagenberg.mc.file;

public class ParseTokens {

	@SuppressWarnings("unused")
	public void tagIdentifiers(String line)  {

		ConstantBytes constantObj = new ConstantBytes();
		RandomBytes randomObj = new RandomBytes();

		System.out.println("parsing tokens");
		String[] arrayRead = line.split("\\s+");
		int byteValue = Integer.parseInt(arrayRead[0]);
		String byteType = arrayRead[1];
		String tag = arrayRead[2];
		int count = 0;
		int min = 0;
		int max = 0;
		if (tag.equalsIgnoreCase("constant")) {
			count=byteValue;
			constantObj.writeConstantBytes(arrayRead,count);
		} else {
			if (arrayRead.length > 4) {
				min = Integer.parseInt(arrayRead[3]);
				max = Integer.parseInt(arrayRead[4]);
				count = Integer.parseInt(arrayRead[5]);
				randomObj.writeRandomBytes(min,max,count);

			} else {
				count = Integer.parseInt(arrayRead[3]);
				randomObj.writeRandomBytes(count);
			}

		}

	}

}
