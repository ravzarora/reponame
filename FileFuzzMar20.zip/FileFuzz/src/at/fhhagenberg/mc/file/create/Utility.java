package at.fhhagenberg.mc.file.create;

import java.io.IOException;

import at.fhhagenberg.mc.file.WriteBinaryFile;

public class Utility {
	String filepath="";
	 String exePath="java -jar DisplayFile.jar";
	 WriteBinaryFile bf=new WriteBinaryFile();
	public void saveFile(String exePath1) {
		try {
			filepath=bf.outputPath;
			exePath=exePath+" "+filepath;
			Process proc=Runtime.getRuntime().exec(exePath);
			System.out.println("exec path "+exePath1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}

}
