package at.fhhagenberg.mc.file;

import java.math.BigInteger;

import at.fhhagenberg.mc.file.append.AppendFile;
import at.fhhagenberg.mc.file.create.Utility;
import at.fhhagenberg.mc.file.display.UtilityB;

public class ParseTokens {
	private String filepath="";

	@SuppressWarnings("unused")
	public void tagIdentifiers(String line) {

		ConstantBytes constantObj = new ConstantBytes();
		RandomBytes randomObj = new RandomBytes();
		AppendFile appendObj=new AppendFile();
		UtilityB utilityB=new UtilityB();

		System.out.println("parsing tokens");
		String[] arrayRead = line.split("\\s+");
		int byteValue = Integer.parseInt(arrayRead[0]);
		String byteType = arrayRead[1];
		String tag = arrayRead[2];
		
		int count = 0;
		int elements = 0;
		int min = 0;
		int max = 0;
		if (tag.equalsIgnoreCase("constant")) {
			
			
			elements = arrayRead.length - 3;
			count = byteValue;

			constantObj.writeConstantBytes(arrayRead, count);
			
			
			

		} else if (tag.equalsIgnoreCase("random")) {
			
			
				if (arrayRead.length > 4) {
			try {
				min = Integer.parseInt(arrayRead[3]);
				max = Integer.parseInt(arrayRead[4]);
				count = Integer.parseInt(arrayRead[5]);
				randomObj.writeRandomBytes(min, max, count);
			}catch(NumberFormatException e) {
				System.out.println("no int bytes");
				//do something here
				String[] tempArr = new String[arrayRead.length - 4];
				byte[] bytes = new byte[arrayRead.length - 4];
				int i=0;
				for(i=3;i<arrayRead.length-1;i++) {
					tempArr[i-3]=arrayRead[i];
					byte temp = Byte.decode(tempArr[i-3]);
					bytes[i - 3] = temp;
				}
				System.out.println("calculating equivalent int value");
				BigInteger bi = new BigInteger(bytes);
				int a=bi.intValue();
				//System.out.println("big integer : " + bi);
				//System.out.println("value of i : " + i);

				count=Integer.parseInt(arrayRead[i]);
				System.out.println("value of count : " + count);

				randomObj.writeRandomBytes(0, a, count);
			}
			
			} 
				
				else {
				
					count = Integer.parseInt(arrayRead[3]);
				
				randomObj.writeRandomBytes(count);
				
			}
		
			

		}
		
		
		else {
			count=byteValue;
			String executablePath=tag;
			if(byteType.equalsIgnoreCase("executable")) {
				System.out.println("hello");
				utilityB.openWithExecutable(executablePath,count);

			}
			else
			{
				
				//	setFilepath(tag);
					appendObj.append(count, tag);
			}
			
			
		}
		}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

}
