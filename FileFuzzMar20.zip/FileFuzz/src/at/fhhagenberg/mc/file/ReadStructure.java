package at.fhhagenberg.mc.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ReadStructure {
	static int rows;

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		ParseTokens tokenObj = new ParseTokens();
		File file = new File("res/file.txt");
		//File file = new File("res/bmpStructure.txt");
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		try {
			@SuppressWarnings("resource")
			FileOutputStream writer = new FileOutputStream("res/structuredOutput.txt");
			@SuppressWarnings("resource")
			FileOutputStream writer1 = new FileOutputStream("res/binary.bmp");
			//FileOutputStream writer1 = new FileOutputStream("res/test.bmp");

			Scanner sc = new Scanner(file);
			while (sc.hasNextLine()) {
				ArrayList<String> line = new ArrayList<String>();
				final String nextLine = sc.nextLine();
				final String[] items = nextLine.split(" ");
				for (int i = 0; i < items.length; i++) {
					line.add(items[i]);
				}
				data.add(line);

				rows++;
				Arrays.fill(items, null);
			}

			for (int i = 0; i < rows; i++) {
				String value1 = "";
				for (int j = 0; j < data.get(i).size(); j++) {

					value1 += data.get(i).get(j) + " ";
				}

				//value1 += "\n";
				tokenObj.tagIdentifiers(value1);

			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (@SuppressWarnings("hiding") IOException e) {
			e.printStackTrace();
		}

	}

}
