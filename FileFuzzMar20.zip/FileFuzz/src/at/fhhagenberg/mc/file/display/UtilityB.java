package at.fhhagenberg.mc.file.display;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import at.fhhagenberg.mc.file.WriteBinaryFile;

public class UtilityB {
	String filepath="";
	long fileSize=0;
	WriteBinaryFile bf=new WriteBinaryFile();
	public  void openWithExecutable(String exePath,int byteCount) {

		try {
			
			filepath=bf.outputPath;
			File file=new File(filepath);
			fileSize=file.length();
			System.out.println("length of binary file is"+fileSize);
            Runtime rt = Runtime.getRuntime();
            //Process pr = rt.exec("cmd /c dir");
            Process pr = rt.exec(exePath+ " "+filepath +" "+byteCount);

            BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));

            String line=null;

            while((line=input.readLine()) != null) {
                System.out.println(line);
            }

            int exitVal = pr.waitFor();
            System.out.println("Exited with error code "+exitVal);

        } catch(Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        }
	}

}
