package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
public class ConstantBytes {

	public static WriteByteFile writeObj = new WriteByteFile();
	public static WriteBinaryFile binaryObj = new WriteBinaryFile();

	String outText = "";
	String s = "";

	public void writeConstantBytes(String array[], int count) {

		byte[] bytes = new byte[count];
		int i = 0;
		int j = 0;
		String[] tempArr = new String[array.length - 3];
		for (i = 3; i < count + 3; i++) {

			try {
				outText += array[i] + " ";
				int b = Integer.decode(array[i]);
				byte temp = (byte) b;
				bytes[i - 3] = temp;

				tempArr[i - 3] = array[i];
			} catch (ArrayIndexOutOfBoundsException exception) {

				outText += tempArr[j] + " ";
				int b = Integer.decode(tempArr[j]);
				byte temp = (byte) b;
				bytes[i - 3] = temp;
				if (j < tempArr.length - 1)
					j++;
				else
					j = 0;
			}

		}
		binaryObj.writeBinary(bytes);

		outText += "\n";
		writeObj.writeBytes(outText);

	}

}
