package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
import java.nio.ByteBuffer;
import java.util.Random;

public class RandomBytes {
	int randomValue = 0;
	String outText = "";

	public void writeRandomBytes(int min, int max, int count) {

		for (int i = 0; i < count; i++) {
			Random rand = new Random();

			randomValue = (min) + rand.nextInt((max - min) + 1);
			byte[] bytes = ByteBuffer.allocate(4).putInt(randomValue).array();

			for (int j = 0; j < 4; j++) {
				outText += String.format("0x%X ", bytes[j]);
			}
			ConstantBytes.binaryObj.writeBinary(bytes);

			outText += "\n";
		}
		ConstantBytes.writeObj.writeBytes(outText);

	}

	public void writeRandomBytes(int count) {
		for (int i = 0; i < count; i++) {
			Random rand = new Random();
			byte[] bytes = ByteBuffer.allocate(4).putInt(rand.nextInt() & Integer.MAX_VALUE).array();
			for (int j = 0; j < 4; j++) {
				outText += String.format("0x%X ", bytes[j]);
			}
			ConstantBytes.binaryObj.writeBinary(bytes);

			outText += "\n";
		}
		ConstantBytes.writeObj.writeBytes(outText);

	}

}
