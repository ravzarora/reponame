package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class WriteByteFile {

	public void writeBytes(String value) {
		String outputPath = "res/StructuredOutput.txt";
		try {

			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(outputPath, true)));
			writer.print(value);
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
