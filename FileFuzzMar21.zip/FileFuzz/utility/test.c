#include <stdio.h>
#include <ctype.h>
int main(int argc, const char *argv[]) {
    int byteCount=atoi(argv[2]);
    
    if(argc!=3){
printf("usage: %s filename",argv[0]);

}else{
FILE *file = fopen( argv[1], "r" );
if ( file == 0 )
        {
            printf( "Could not open file\n" );
        }else
{
            int counter=0;
            int c;
            /* read one character at a time from file, stopping at EOF, which
               indicates the end of the file.  Note that the idiom of "assign
               to a variable, check the value" used below works because
               the assignment statement evaluates to the value assigned. */
            while  ( ( c = fgetc( file ) ) != EOF && counter<byteCount )
            {   
                if(isprint(c)!=0)
                printf("%c ",c );
                else
                printf(".");
                counter++;   
                
            }
            fclose( file );
        }
}

    }
