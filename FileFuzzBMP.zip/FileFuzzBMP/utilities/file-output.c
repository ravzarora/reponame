#include <stdio.h>
#include <ctype.h>
    int main(int argc, const char *argv[]) {
    int byteCount=atoi(argv[2]);
    
    if(argc!=3){
                printf("usage: %s filename",argv[0]);

               }else{
                FILE *file = fopen( argv[1], "r" );
                if ( file == 0 )
               {
                printf( "Could not open file\n" );
               }else
                {
                 int counter=0;
                 int readCount=0;
                 int c;
    
            while  ( ( c = fgetc( file ) ) != EOF && readCount<byteCount )
             {    
               if(isprint(c)!=0)
                printf("%c",c );
                else
                printf(".");
                counter++;
                if(counter==16) {
                printf("\n");
                  counter=0;
              }
              readCount++;  
             }
            fclose( file );
        }
      }
}
