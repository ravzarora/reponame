package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
import java.math.BigInteger;

import at.fhhagenberg.mc.file.append.AppendFile;
import at.fhhagenberg.mc.file.display.UtilityOpenFile;

public class ParseTokens {
	private String filepath = "";

	@SuppressWarnings("unused")
	public void tagIdentifiers(String line) {

		ConstantBytes constantObj = new ConstantBytes();
		RandomBytes randomObj = new RandomBytes();
		AppendFile appendObj = new AppendFile();
		UtilityOpenFile utilityB = new UtilityOpenFile();

		String[] arrayRead = line.split("\\s+");
		int byteValue = 0;
		try {
			byteValue = Integer.parseInt(arrayRead[0]);
		} catch (NumberFormatException e) {
			System.out.println("Invalid File Structure");
		}
		String byteType = arrayRead[1];
		String tag = arrayRead[2];

		int count = 0;
		int elements = 0;
		int min = 0;
		int max = 0;

		if (tag.equalsIgnoreCase("constant")) {

			elements = arrayRead.length - 3;
			count = byteValue;

			constantObj.writeConstantBytes(arrayRead, count);

		} else if (tag.equalsIgnoreCase("random")) {

			if (arrayRead.length > 4) {
				try {
					min = Integer.parseInt(arrayRead[3]);
					max = Integer.parseInt(arrayRead[4]);
					count = Integer.parseInt(arrayRead[5]);
					randomObj.writeRandomBytes(min, max, count);
				} catch (NumberFormatException e) {
					String[] tempArr = new String[arrayRead.length - 4];
					byte[] bytes = new byte[arrayRead.length - 4];
					int i = 0;
					for (i = 3; i < arrayRead.length - 1; i++) {
						tempArr[i - 3] = arrayRead[i];
						byte temp = Byte.decode(tempArr[i - 3]);
						bytes[i - 3] = temp;
					}
					BigInteger bi = new BigInteger(bytes);
					int a = bi.intValue();

					count = Integer.parseInt(arrayRead[i]);

					randomObj.writeRandomBytes(0, a, count);
				}

			}

			else {

				count = Integer.parseInt(arrayRead[3]);

				randomObj.writeRandomBytes(count);

			}

		}

		else {
			count = byteValue;
			String executablePath = tag;
			if (byteType.equalsIgnoreCase("executable")) {
				utilityB.openWithExecutable(executablePath, count);

			} else {

				appendObj.append(count, tag);
			}

		}
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

}
