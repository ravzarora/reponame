package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ReadStructure {
	static int rows;

	@SuppressWarnings("unused")
	public  void readInputFile(String _file) {

		ParseTokens tokenObj = new ParseTokens();
		File file = new File(_file);
		// File file = new File("res/BMPStructure.txt");
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		try {
			@SuppressWarnings("resource")
			FileOutputStream writer = new FileOutputStream("/Users/student/Projects/FileFuzzBMP/res/StructuredOutput.txt");
			@SuppressWarnings("resource")
			FileOutputStream writer1 = new FileOutputStream("/Users/student/Projects/FileFuzzBMP/res/GeneratedFile.bmp");
			// FileOutputStream writer1 = new FileOutputStream("res/BMPTest.bmp");

			Scanner sc = new Scanner(file);
			while (sc.hasNextLine()) {
				ArrayList<String> line = new ArrayList<String>();
				final String nextLine = sc.nextLine();
				final String[] items = nextLine.split(" ");
				for (int i = 0; i < items.length; i++) {
					line.add(items[i]);
				}
				data.add(line);

				rows++;
				Arrays.fill(items, null);
			}

			for (int i = 0; i < rows; i++) {
				String value1 = "";
				for (int j = 0; j < data.get(i).size(); j++) {

					value1 += data.get(i).get(j) + " ";
				}

				tokenObj.tagIdentifiers(value1);

			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (@SuppressWarnings("hiding") IOException e) {
			e.printStackTrace();
		}

	}

}
