package at.fhhagenberg.mc.file.display;



public class Logger {
	
	UtilityOpenFile utilityOpenObj=new UtilityOpenFile();
	int successFlag=0;
	
	public void Logger() {
		if(utilityOpenObj.exitValue==0)
			successFlag=1;
		else 
			successFlag=0;
		
		
			
	}
	

}
