package at.fhhagenberg.mc.file.display;

/*
 * @author RavdeepArora 
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

import at.fhhagenberg.mc.file.WriteBinaryFile;

public class UtilityOpenFile {
	Process pr;
	
	int exitValue=-1;
	String filepath = "";
	long fileSize = 0;
	WriteBinaryFile bf = new WriteBinaryFile();

	public void openWithExecutable(String exePath, long byteCount) {

		try {

			filepath = bf.outputPath;
			File file = new File(filepath);
			fileSize = file.length();
			if (byteCount == 0) {
				byteCount = fileSize;
				System.out.println("Bytes Read: " + byteCount);
			} else if (byteCount > fileSize) {
				byteCount = fileSize;
				System.out.println("Request exceeds FileSize!!! Bytes Available: " + byteCount);
			} else
				System.out.println("Bytes Read: " + byteCount);

			Runtime rt = Runtime.getRuntime();
			pr = rt.exec(exePath + " " + filepath + " " + byteCount);
			
			BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
			

			String line = null;

			while ((line = input.readLine()) != null) {
				System.out.println(line);
			}
			
			exitValue = pr.waitFor();
			
			
			System.out.println("Exited with error code " + exitValue);
	        
		
			
			

		} catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}
	
	


}
