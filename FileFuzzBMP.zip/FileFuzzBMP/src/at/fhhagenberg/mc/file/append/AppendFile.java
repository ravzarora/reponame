package at.fhhagenberg.mc.file.append;

/*
 * @author RavdeepArora 
 */
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import at.fhhagenberg.mc.file.ConstantBytes;
import at.fhhagenberg.mc.grammar.BmpGenerator;

public class AppendFile {
	BmpGenerator generator=new BmpGenerator();

	public void append(int count, String filepath) {
		File file = new File(filepath);
		try {
			if(count==0)
				count=(int) file.length();
				
			@SuppressWarnings("resource")
			FileInputStream fin = new FileInputStream(file);
			byte fileContent[] = new byte[count];
			fin.read(fileContent);
			byte byteFileContent[] = new byte[count];
			for (int i = 0; i < count; i++) {
				byteFileContent[i] = fileContent[i];

			}
			
			ConstantBytes.binaryObj.writeBinary(byteFileContent);


		} catch (FileNotFoundException e) {
			System.out.println("File not found " + e);

		} catch (IOException e) {

			System.out.println("Exception while reading the file " + e);
		}

	}

}
