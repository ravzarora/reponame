package at.fhhagenberg.mc.file;

/*
 * @author RavdeepArora 
 */
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class WriteBinaryFile {
	public String outputPath = "/Users/student/Projects/FileFuzzBMP/res/GeneratedFile.bmp";

	public void writeBinary(byte[] bytes) {
		// String outputPath = "res/BMPTest.bmp";

		try {
			FileOutputStream binWrite = new FileOutputStream(outputPath, true);
			DataOutputStream writer = new DataOutputStream(binWrite);
			writer.write(bytes);
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
