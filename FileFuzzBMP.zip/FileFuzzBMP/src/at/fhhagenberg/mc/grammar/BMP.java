package at.fhhagenberg.mc.grammar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import at.fhhagenberg.mc.file.ReadStructure;

public class BMP {
	private final static int BMP_CODE = 19778;

	byte [] data;
	int size=0;
	public void saveBMP(String filename, int [][] rgbValues){
		try {
			FileOutputStream fos = new FileOutputStream(new File(filename));
			
			data = new byte[54 + 3*rgbValues.length*rgbValues[0].length + getPadding(rgbValues[0].length)*rgbValues.length];
			saveHeader();
			saveInfoHeader(rgbValues.length, rgbValues[0].length);
			saveRgbQuad();
			saveBitmapData(rgbValues);
			writeSize();

			fos.write(data);
			
			fos.close();

			
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			
		}
		
	}

	private void saveHeader() {
		byte[]array=intToTwoByteValue(BMP_CODE);
		data[0]=array[1];
		data[1]=array[0];
		
		array=intToFourByteValue(data.length);
		data[5]=array[0];
		data[4]=array[1];
		data[3]=array[2];
		data[2]=array[3];
		
		//offset value
		data[10]=54;
	}
	
	private void saveInfoHeader(int height, int width) {
		data[14]=40;
		
		byte[]a=intToFourByteValue(width);
		data[22]=a[3];
		data[23]=a[2];
		data[24]=a[1];
		data[25]=a[0];
		
		a=intToFourByteValue(height);
		data[18]=a[3];
		data[19]=a[2];
		data[20]=a[1];
		data[21]=a[0];
		
		data[26]=1;
		
		data[28]=24;
		
		a=intToFourByteValue(2835);
		data[38]=a[3];
		data[39]=a[2];
		data[40]=a[1];
		data[41]=a[0];
		a=intToFourByteValue(2835);
		data[42]=a[3];
		data[43]=a[2];
		data[44]=a[1];
		data[45]=a[0];
		
	}
	
	private void saveRgbQuad() {
		
	}

	private void saveBitmapData(int[][]rgbValues) {
		int i;
		
		for(i=0;i<rgbValues.length;i++){
			writeLine(i, rgbValues);
			
		}
		
	}
	
	private void writeLine(int row, int [][] rgbValues) {
		
		final int offset=54;
		final int rowLength=rgbValues[row].length;
		final int padding = getPadding(rgbValues[0].length);
		int i;
		
		for(i=0;i<rowLength;i++){
			int rgb=rgbValues[row][i];
			int temp=offset + 3*(i+rowLength*row) + row*padding;
			int a= (int)(Math.random()*256);
			int r= (int)(Math.random()*256);
			int g= (int)(Math.random()*256);
			int b= (int)(Math.random()*256);
			
			int p= (a<<24) |(r<<16) |(g<<8)| b;
			
			data[temp]    =  (byte) (p) ;
			data[temp +1] = (byte) (p );
			data[temp +2] = (byte) (p );
			size=size+3;
			//bytes[temp]    =  (byte) ((rgb>>16) ) ;
			//bytes[temp +1] = (byte) ((rgb>>8) );
			//bytes[temp +2] = (byte) ((rgb) );
		}
		i--;
		int temp=offset + 3*(i+rowLength*row) + row*padding+3;
		size=size+padding;
		for(int j=0;j<padding;j++)
			data[temp +j]=0;
		
		
	}
	
	private void writeSize() {
		
		byte[]a=intToFourByteValue(size);
		data[34]=a[3];
		data[35]=a[2];
		data[36]=a[1];
		data[37]=a[0];
		
	}

	
	private byte[] intToTwoByteValue(int x){
		byte [] array = new byte[2];
		
		array[1]=(byte)  x;
		array[0]=(byte) (x>>8);
		
		return array;
	}
	
	private byte[] intToFourByteValue(int x){
		byte [] array = new byte[4];
		
		array[3]=(byte)  x;
		array[2]=(byte) (x>>8);
		array[1]=(byte) (x>>16);
		array[0]=(byte) (x>>24);
		
		return array;
	}
	
	private int getPadding(int rowLength){
		
		int padding = (3*rowLength)%4;
		
		if(padding!=0)
		{
			
			padding=4-padding;
			
		   
		}
			
			
		 
		
		return padding;
	}
	
}