package at.fhhagenberg.mc.grammar;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import at.fhhagenberg.mc.file.ReadStructure;

public class BmpGenerator {

	

	public void generator(int n) throws IOException {
	/*	if(args.length == 0) {
            System.out.println("File name not specified.");
            System.exit(1);
        }
		
		String file = args[0];
		String filename = "/Users/student/Projects/FileFuzzBMP/res/test.bmp";*/
		String filename = "res/test.bmp";
		ReadStructure readObj=new ReadStructure();

		BMP bmpObj=new BMP();
		int [][] rgbValues=new int [0][0];
			rgbValues= new int[n][n];
			bmpObj.saveBMP(filename, rgbValues);

		


		readObj.readInputFile("res/InputStructure.txt");

		
		
		
		
	}

}
