package at.fhhagenberg.mc.grammar;

import java.io.File;

import at.fhhagenberg.mc.file.ReadStructure;

public class BmpGenerator {

	

	public static void main(String[] args) {
		if(args.length == 0) {
            System.out.println("File name not specified.");
            System.exit(1);
        }
		
		String file = args[0];
		String filename = "/Users/student/Projects/FileFuzzBMP/res/test.bmp";
		int [][] rgbValues=new int [10][20];
		BMP bmpObj=new BMP();
		
		bmpObj.saveBMP(filename, rgbValues);
		
		ReadStructure readObj=new ReadStructure();
		readObj.readInputFile(file);
		
		
	}

}
