package at.fhhagenberg.mc.grammar;

import at.fhhagenberg.mc.file.ReadStructure;

public class BmpGenerator {

	

	public static void main(String[] args) {
		String filename = "res/test.bmp";
		int [][] rgbValues=new int [10][20];
		BMP bmpObj=new BMP();
		
		bmpObj.saveBMP(filename, rgbValues);
		
		ReadStructure readObj=new ReadStructure();
		readObj.readInputFile();
		
		
	}

}
