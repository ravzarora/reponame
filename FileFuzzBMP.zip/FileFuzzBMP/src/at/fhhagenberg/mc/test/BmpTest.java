package at.fhhagenberg.mc.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.lang.annotation.Repeatable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import at.fhhagenberg.mc.file.display.UtilityOpenFile;
import at.fhhagenberg.mc.grammar.BmpGenerator;
import junit.extensions.RepeatedTest;

@RunWith(Parameterized.class)
public class BmpTest {
	BmpGenerator generatorObj = new BmpGenerator();
	@Parameters
	public static Object[] data() {
	    return new Object[] { 1, 2};
	}


	
	@Test
	public void test_bmp_file(int n) throws IOException, InterruptedException {
		System.out.println("Test function created");
		n=1;
		generatorObj.generator(1);
		Files.move(Paths.get("res/GeneratedFile.bmp"), Paths.get("fuzzedFiles/Test"+n+".bmp"), StandardCopyOption.REPLACE_EXISTING);

		
		 
	}

}
