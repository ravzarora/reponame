package at.fhhagenberg.mc.test;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.annotation.Repeatable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import at.fhhagenberg.mc.file.display.UtilityOpenFile;
import at.fhhagenberg.mc.grammar.BmpGenerator;
import junit.extensions.RepeatedTest;
import junit.framework.TestCase;

@RunWith(Parameterized.class)
public class BmpTest {
	
	@Parameter
     public int n;
	BmpGenerator generatorObj = new BmpGenerator();
	Runtime testRunTime = Runtime.getRuntime();
	Process testProcessStart;
	Process testProcessQuit;
	int exitValue=0;
	@Parameters
	public static Object[] data() {
	    return new Object[] { 6,7
	    		
};
	}

	
	public void BmpTest() throws IOException, InterruptedException {
		
	}
	
	@Test
	public void Test() throws IOException, InterruptedException {
		generatorObj.generator(n);
		Files.move(Paths.get("res/GeneratedFile.bmp"), Paths.get("fuzzedFiles/Test"+n+".bmp"), StandardCopyOption.REPLACE_EXISTING);
		testProcessStart = testRunTime.exec("/Applications/Sequential.app/Contents/MacOS/Sequential");
		System.out.println("Test"+n+".bmp "+"passed");

}
	
	@After
    public void tearDown() throws IOException, InterruptedException {
          
		testProcessQuit = testRunTime.exec("killall Sequential");
		

    }
	

	
}