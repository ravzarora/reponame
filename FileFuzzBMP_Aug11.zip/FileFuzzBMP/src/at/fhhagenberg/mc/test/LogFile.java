package at.fhhagenberg.mc.test;

public class LogFile {
	
	public String outputPath = "res/LogFile.text";
	

}
